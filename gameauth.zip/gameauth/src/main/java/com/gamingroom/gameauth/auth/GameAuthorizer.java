package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;
import com.fasterxml.Configuration;
import org.hibernate.validator.contraints.*;
import javax.validation.contraints.*:

public class GameAuthorizer implements Authorizer<GameUser> 
{
    @Override
    public boolean authorize(GameUser user, String role) {
   
    	
    }
}